<div class="form-group <?php echo e($errors->has('kode') ? 'has-error' : ''); ?>">
    <?php echo Form::label('kode', 'Kode', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('kode', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('kode', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('jumlah') ? 'has-error' : ''); ?>">
    <?php echo Form::label('jumlah', 'Jumlah', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('jumlah', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('jumlah', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('keterangan') ? 'has-error' : ''); ?>">
    <?php echo Form::label('keterangan', 'Keterangan', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('keterangan', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('keterangan', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
