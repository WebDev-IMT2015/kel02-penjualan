<div class="form-group <?php echo e($errors->has('customer') ? 'has-error' : ''); ?>">
    <?php echo Form::label('customer', 'Customer', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('customer', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('customer', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('tanggal') ? 'has-error' : ''); ?>">
    <?php echo Form::label('tanggal', 'Tanggal', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::input('datetime-local', 'tanggal', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('tanggal', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('belanjaan') ? 'has-error' : ''); ?>">
    <?php echo Form::label('belanjaan', 'Belanjaan', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('belanjaan', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('belanjaan', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('jumlah') ? 'has-error' : ''); ?>">
    <?php echo Form::label('jumlah', 'Jumlah', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('jumlah', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('jumlah', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
