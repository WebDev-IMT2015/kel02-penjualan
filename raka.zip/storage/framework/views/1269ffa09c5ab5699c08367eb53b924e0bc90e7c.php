<div class="col-md-3">
    <div class="panel panel-default panel-flush">
        <div class="panel-heading">
            Sidebar
        </div>

        <div class="panel-body">
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a href="<?php echo e(url('/admin')); ?>">
                        Dashboard
                    </a>
                </li>
                <li role="presentation">
                    <a href="<?php echo e(url('/admin/produk')); ?>">
                        Produk
                    </a>
                </li>
                <li role="presentation">
                    <a href="<?php echo e(url('/admin/history')); ?>">
                        History Penjualan
                    </a>
                </li>
                <li role="presentation">
                    <a href="<?php echo e(url('/admin/account')); ?>">
                        Manage User
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
